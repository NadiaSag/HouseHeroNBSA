package com.nasch.househero.dataclasses
data class Municipio(
    val parent_code: String,
    val code: String,
    val label: String
)